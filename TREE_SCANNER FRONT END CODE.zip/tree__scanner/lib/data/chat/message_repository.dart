// import 'dart:convert';
// import 'dart:io';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart';

// import '../../utilis/constants/notification_access_token.dart';
// import '../../feature/authentication/models/user_model.dart';
// import '../../feature/home/model/message_model.dart';

// class MessageRepository {
//   static MessageRepository get instance => Get.find();

//   // Variables
//   final FirebaseFirestore firestore = FirebaseFirestore.instance;
//   final FirebaseStorage storage = FirebaseStorage.instance;
//   final FirebaseAuth _auth = FirebaseAuth.instance;
  
//   // Get Authenticated User Data
//   User get authUser => _auth.currentUser!;

//   // for sending push notification (Updated Codes)
//   static Future<void> sendPushNotification(
//       UserModel chatUser, String msg) async {
//     try {
//       final body = {
//         "message": {
//           "token": chatUser.pushToken,
//           "notification": {
//             "title": chatUser.fullname,
//             "body": msg,
//           },
//         }
//       };

//       // Firebase Project > Project Settings > General Tab > Project ID
//       const projectID = 'timesy-17e70';

//       // get firebase admin token
//       final bearerToken = await NotificationAccessToken.getToken;

//       print('bearerToken: $bearerToken');

//       // handle null token
//       if (bearerToken == null) return;

//       var res = await post(
//         Uri.parse(
//             'https://fcm.googleapis.com/v1/projects/$projectID/messages:send'),
//         headers: {
//           HttpHeaders.contentTypeHeader: 'application/json',
//           HttpHeaders.authorizationHeader: 'Bearer $bearerToken'
//         },
//         body: jsonEncode(body),
//       );

//       print('Response status: ${res.statusCode}');
//       print('Response body: ${res.body}');
//     } catch (e) {
//       print('\nsendPushNotificationE: $e');
//     }
//   }

//   String getConversationID(String id) {
//     // useful for getting conversation id
//     final user = _auth.currentUser!;
//     return user.uid.hashCode <= id.hashCode
//         ? '${user.uid}_$id'
//         : '${id}_${user.uid}';
//   }

//   // Get All Message of Users
//   Stream<QuerySnapshot<Map<String, dynamic>>> getAllMessages(UserModel user) {
//     return firestore
//         .collection('chats/${getConversationID(user.id)}/messages/')
//         .orderBy('sent', descending: true)
//         .snapshots();
//   }

//   // for sending message
//   Future<void> sendMessage(UserModel chatUser, String msg, Type type) async {
//     //message sending time (also used as id)
//     final time = DateTime.now().millisecondsSinceEpoch.toString();
//     final user = _auth.currentUser!;

//     //message to send
//     final Message message = Message(
//         toId: chatUser.id,
//         msg: msg,
//         read: '',
//         type: type,
//         fromId: user.uid,
//         sent: time);

//     final ref = firestore
//         .collection('chats/${getConversationID(chatUser.id)}/messages/');
//     await ref.doc(time).set(message.toJson()).then((value) =>
//         sendPushNotification(chatUser, type == Type.text ? msg : 'image'));
//   }

//   //update read status of message
//   Future<void> updateMessageReadStatus(Message message) async {
//     firestore
//         .collection('chats/${getConversationID(message.fromId)}/messages/')
//         .doc(message.sent)
//         .update({'read': DateTime.now().millisecondsSinceEpoch.toString()});
//   }

//   //get only last message of a specific chat
//   Stream<QuerySnapshot<Map<String, dynamic>>> getLastMessage(UserModel user) {
//     return firestore
//         .collection('chats/${getConversationID(user.id)}/messages/')
//         .orderBy('sent', descending: true)
//         .limit(1)
//         .snapshots();
//   }

//   //send chat image
//   Future<void> sendChatImage(UserModel chatUser, File file) async {
//     //getting image file extension
//     final ext = file.path.split('.').last;

//     //storage file ref with path
//     final ref = storage.ref().child(
//         'images/${getConversationID(chatUser.id)}/${DateTime.now().millisecondsSinceEpoch}.$ext');

//     //uploading image
//     await ref
//         .putFile(file, SettableMetadata(contentType: 'image/$ext'))
//         .then((p0) {
//       print('Data Transferred: ${p0.bytesTransferred / 1000} kb');
//     });

//     //updating image in firestore database
//     final imageUrl = await ref.getDownloadURL();
//     await sendMessage(chatUser, imageUrl, Type.image);
//   }

//   //delete message
//   Future<void> deleteMessage(Message message) async {
//     await firestore
//         .collection('chats/${getConversationID(message.toId)}/messages/')
//         .doc(message.sent)
//         .delete();

//     if (message.type == Type.image) {
//       await storage.refFromURL(message.msg).delete();
//     }
//   }

//   //update message
//   Future<void> updateMessage(Message message, String updatedMsg) async {
//     await firestore
//         .collection('chats/${getConversationID(message.toId)}/messages/')
//         .doc(message.sent)
//         .update({'msg': updatedMsg});
//   }

//    Future<void> sendFirstMessage(
//       UserModel chatUser, String msg, Type type) async {
//     await firestore
//         .collection('users')
//         .doc(chatUser.id)
//         .collection('my_users')
//         .doc(authUser.uid)
//         .set({}).then((value) => sendMessage(chatUser, msg, type));
//   }
// }
