import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../utilis/constants/colors.dart';
import '../../../utilis/helpers/helper_function.dart';
import '../home/scan_screen.dart';
import '../home/details_screen.dart';
import '../home/diagnose_screen.dart';
import '../setting/profile/profile.dart';


class NavigationMenu extends StatelessWidget {
  const NavigationMenu({super.key});

  @override
  Widget build(BuildContext context) {
    final controlller = Get.put(NavBarController());
    final dark = THelperFunctions.isDarkMode(context);
    return Scaffold(
      bottomNavigationBar: Obx(
        () => NavigationBarTheme(
          data: NavigationBarThemeData(
            backgroundColor: dark ? WColors.black : WColors.primary,
            indicatorColor: dark
                ? WColors.white.withOpacity(0.1)
                : WColors.black.withOpacity(0.1),
            labelTextStyle: WidgetStateProperty.all(
              const TextStyle(color: Colors.white,fontSize: 12),
            ),
            iconTheme: WidgetStateProperty.all(
              const IconThemeData(color: Colors.white),
            ),
          ),
          child:  NavigationBar(
          height: 80,
          elevation: 0,
          selectedIndex: controlller.selectedIndex.value,
          onDestinationSelected: (index) =>
              controlller.selectedIndex.value = index,
          destinations: const [
            NavigationDestination(icon: Icon(Iconsax.home), label: 'Home'),
            NavigationDestination(
                icon: Icon(Iconsax.document), label: 'Diagnose'),
            NavigationDestination(
                icon: Icon(Iconsax.scan), label: 'Scan Tree'),
            NavigationDestination(icon: Icon(Iconsax.user), label: 'Profile'),
          ],
        ),
      ),
      ),
      body: Obx(() => controlller.screens[controlller.selectedIndex.value]),
    );
  }
}

class NavBarController extends GetxController {
  final Rx<int> selectedIndex = 0.obs;

  final screens = const [
    DetailsScreen(),
    DiagnosePage(),
    ScanScreen(),
    UserProfile(),
    // TherapistHome(),
    // PatientAppointment(),
    // MonitiringProgress(),
    // TherapistDetailsScreen()
  ];
}

