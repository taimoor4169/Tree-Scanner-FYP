import 'package:flutter/material.dart';

class TreeScannerScreen extends StatelessWidget {
  static const routeName = '/tree-scanner';  // Define the route name

  const TreeScannerScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tree Scanner")),
      body: Center(child: const Text('Welcome to Tree Scanner!')),
    );
  }
}
