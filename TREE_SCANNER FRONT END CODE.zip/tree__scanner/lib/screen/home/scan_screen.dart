import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'dart:io';
import '../../common/widgets/containers/rounded_button.dart';
import '../../utilis/constants/colors.dart';
import 'controller/scran_tree_controller.dart';

class ScanScreen extends StatelessWidget {
  const ScanScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final homecontroller = Get.put(ScanTreeController());
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: WColors.white),
        backgroundColor: WColors.primary,
        title: Text(
          'Scan Tree',
          style: Theme.of(context)
              .textTheme
              .headlineSmall!
              .copyWith(color: WColors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Obx(
              () => homecontroller.selectedImagePath.value.isNotEmpty
                  ? Container(
                      width: double.infinity,
                      height: 300,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: FileImage(
                              File(homecontroller.selectedImagePath.value)),
                          fit: BoxFit.cover,
                        ),
                      ),
                    )
                  : SizedBox(
                      width: double.infinity,
                      height: 300,
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border.all(width: 1, color: WColors.black)),
                        child: Center(
                          child: Padding(
                            padding: const EdgeInsets.all(18.0),
                            child: Column(
                              children: [
                                Image(
                                  image: const AssetImage(
                                      'assets/image-gallery.png'),
                                  color: WColors.black,
                                  width: 150,
                                  height: 150,
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Text(
                                  textAlign: TextAlign.center,
                                  'Select Image from Gallery',
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ), // Display nothing if no image is selected
            ),
            const SizedBox(
              height: 20,
            ),
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                  onPressed: () {
                    homecontroller.uploadImage();
                  },
                  child: const Text('Upload Image')),
            ),
            const SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CustomButton(
                  btnname: 'Scan Tree',
                  icons: Iconsax.scan,
                  onpressed: () {
                    homecontroller.scanTree();
                  },
                ),
                CustomButton(
                  btnname: 'Reset Image',
                  icons: Icons.refresh,
                  onpressed: () {
                    homecontroller.clearSelectedImagePath();
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
