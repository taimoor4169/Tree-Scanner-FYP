
import 'package:flutter/material.dart';

class MyGardenScreen extends StatefulWidget {
  static const routeName = '/my_garden';

  const MyGardenScreen({Key? key}) : super(key: key);

  @override
  _MyGardenScreenState createState() => _MyGardenScreenState();
}

class _MyGardenScreenState extends State<MyGardenScreen> with SingleTickerProviderStateMixin {
  int _plantCount = 0;
  int _reminderCount = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  void _addPlant() {
    setState(() {
      _plantCount++;
    });
  }

  void _addReminder() {
    setState(() {
      _reminderCount++;
    });
  }

  Widget _buildAllPlants() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          _plantCount > 0 ? 'You have $_plantCount plants' : 'No Plants',
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 16),
        const Icon(
          Icons.local_florist,
          size: 100,
          color: Colors.white,
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _addPlant,
          child: const Text('Add Plant'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            elevation: 5,
            shadowColor: Colors.black45,
          ),
        ),
      ],
    );
  }

  Widget _buildReminders() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          _reminderCount > 0 ? 'You have $_reminderCount reminders' : 'No Reminders',
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 16),
        const Icon(
          Icons.alarm,
          size: 100,
          color: Colors.white,
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _addReminder,
          child: const Text('Add Reminder'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            elevation: 5,
            shadowColor: Colors.black45,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('My Garden'),
          backgroundColor: Colors.green,
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.amber,
            indicatorWeight: 4.0,
            tabs: const [
              Tab(
                text: 'All Plants',
                icon: Icon(Icons.local_florist),
              ),
              Tab(
                text: 'Reminders',
                icon: Icon(Icons.alarm),
              ),
            ],
          ),
        ),
        body: Stack(
          children: [
            // Background image
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/background diagnose.png'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
              ),
            ),
            // Content overlay
            TabBarView(
              controller: _tabController,
              children: [
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black45,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    margin: const EdgeInsets.all(16.0),
                    padding: const EdgeInsets.all(16.0),
                    child: _buildAllPlants(),
                  ),
                ),
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6), // Semi-transparent overlay for better readability
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black45,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    margin: const EdgeInsets.all(16.0),
                    padding: const EdgeInsets.all(16.0),
                    child: _buildReminders(),
                  ),
                ),
              ],
            ),
          ],
        ),
    );
  }
}
