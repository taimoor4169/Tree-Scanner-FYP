import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http_parser/http_parser.dart';

import '../../../common/widgets/containers/rounded_button.dart';
import '../../../utilis/loaders/loaders.dart';

class DiagnoseController extends GetxController {
  RxString selectedImagePath = ''.obs;
  String _predictionResult = '';
  bool _isLoading = false; // To show loading spinner

  String get predictionResult => _predictionResult;
  bool get isLoading => _isLoading;

  void clearSelectedImagePath() {
    selectedImagePath.value = '';
  }

  // Upload and select image
  Future<void> uploadImage() async {
    try {
      await showModalBottomSheet(
        context: Get.context!,
        builder: (BuildContext context) {
          return Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Choose an option'),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    CustomButton(
                      btnname: 'Camera',
                      icons: Icons.camera_alt,
                      onpressed: () async {
                        Navigator.pop(context); // Close the bottom sheet
                        final image = await ImagePicker().pickImage(
                          source: ImageSource.camera,
                          imageQuality: 100,
                          maxWidth: 512,
                          maxHeight: 512,
                        );
                        if (image != null) {
                          selectedImagePath.value = image.path;
                          await diagnoseDisease(); // Diagnose after selection
                        }
                      },
                    ),
                    CustomButton(
                      btnname: 'Gallery',
                      icons: Icons.image,
                      onpressed: () async {
                        Navigator.pop(context); // Close the bottom sheet
                        final image = await ImagePicker().pickImage(
                          source: ImageSource.gallery,
                          imageQuality: 100,
                          maxWidth: 512,
                          maxHeight: 512,
                        );
                        if (image != null) {
                          selectedImagePath.value = image.path;
                        }
                      },
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      );
    } catch (e) {
      TLoaders.errorSnackBar(
        title: 'Oops!',
        message: 'Something went wrong: $e',
      );
    }
  }

  // Diagnose the disease
  Future<void> diagnoseDisease() async {
    if (selectedImagePath.value.isEmpty) {
      TLoaders.errorSnackBar(
        title: 'Error',
        message: 'Please select an image before diagnosing!',
      );
      return;
    }

    _isLoading = true;
    update(); // Notify listeners

    // Show progress dialog
    showDialog(
      context: Get.context!,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Processing...'),
            ],
          ),
        );
      },
    );

    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse(
            'https://7e7c-39-41-158-25.ngrok-free.app/predict_disease'), // Endpoint for diagnosis
      );

      var file = await http.MultipartFile.fromPath(
        'file',
        selectedImagePath.value,
        contentType: MediaType('image', 'jpeg'),
      );
      request.files.add(file);

      var response = await request.send();

      // Close the progress dialog before handling the response
      Navigator.of(Get.context!).pop();

      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        var jsonResponse = jsonDecode(responseBody);
        var result =
            jsonResponse['response']; // Adjust to match API response structure

        double predictedProbability = result[
            'predicted_probability']; // Assuming predicted_probability is a double
        String predictedLabel = result['predicted_label'];

        if (predictedProbability > 0.7) {
          _predictionResult =
              'Unknown Image';

          // Show Unknown Error dialog
          showDialog(
            context: Get.context!,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('Diagnosis Result'),
                content: Text(_predictionResult),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text('OK'),
                  ),
                ],
              );
            },
          );
        } else {
          _predictionResult =
              'Predicted Label: $predictedLabel, Probability: $predictedProbability';

          // Show the result dialog with the label and probability
          showDialog(
            context: Get.context!,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('Diagnosis Result'),
                content: Text(_predictionResult),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text('OK'),
                  ),
                ],
              );
            },
          );
        }
      } else {
        _predictionResult =
            'Failed to get prediction. Status Code: ${response.statusCode}';
        TLoaders.errorSnackBar(
          title: 'Error',
          message: _predictionResult,
        );
      }
    } catch (e) {
      // Close the dialog in case of an error
      Navigator.of(Get.context!).pop();

      _predictionResult = 'Error: $e';
      TLoaders.errorSnackBar(
        title: 'Error',
        message: _predictionResult,
      );
    } finally {
      _isLoading = false;
      update(); // Notify listeners
    }
  }
}
