import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'home_pages_screen/similar_plants_screen.dart';
import 'home_pages_screen/tree_species_difference_screen.dart';
import 'home_pages_screen/user_ratings_screen.dart';
import 'home_pages_screen/common_diseases_screen.dart';
import '../../utilis/constants/colors.dart'; // Ensure this file defines WColors
import '../../common/widgets/containers/primary_header_container.dart';
import 'home_pages_screen/articles_and_guides_screen.dart';
import 'home_app_bar.dart';
import 'home_pages_screen/tree_identification_screen.dart';

class DetailsScreen extends StatelessWidget {
  const DetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Primary Header
            TPrimaryHeaderContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const HomeAppBar(),
                  const SizedBox(height: 16),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      children: [
                        Icon(
                          getGreetingIcon(),
                          color: Colors.green,
                          size: 28,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Good ${getGreeting()}!',
                          style: TextStyle(
                            fontSize: 20,
                            color: WColors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Search Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search trees, guides, and more...',
                        prefixIcon: const Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.grey[200],
                      ),
                    ),
                  ),
                  const SizedBox(height: 50),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  // Get Started Section
                  const Text(
                    'Get Started',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _buildActionCard(
                        title: 'How to identify trees?',
                        subtitle: 'Lifestyle',
                        onTap: () {
                          Get.to(() => const TreeIdentificationScreen());
                        },
                      ),
                      const SizedBox(width: 8),
                      _buildActionCard(
                        title: 'Differences between tree species',
                        subtitle: 'Tree Identification',
                        onTap: () {
                          Get.to(TreeSpeciesDifferenceScreen());
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Categories Section
                  const Text(
                    'Categories',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  GridView.count(
                    crossAxisCount:
                        MediaQuery.of(context).size.width > 600 ? 3 : 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _buildCategoryCard(
                        title: 'Article & guides about trees care',
                        imagePath: 'assets/articles and guides.webp',
                        onTap: () =>
                            Get.to(() => const ArticlesAndGuidesScreen()),
                      ),
                      _buildCategoryCard(
                        title: 'Videos on specific tree topics',
                        imagePath: 'assets/videos on specific trees.webp',
                        onTap: () {
                          Get.to(UserRatingsScreen());
                        },
                      ),
                      _buildCategoryCard(
                        title: 'User reviews and ratings',
                        imagePath: 'assets/users ratings.webp',
                        onTap: () {
                          Get.to(UserRatingsScreen());
                        },
                      ),
                      _buildCategoryCard(
                        title: 'Information on similar plants',
                        imagePath: 'assets/information similer plants.webp',
                        onTap: () {
                          Get.to(SimilarPlantsScreen());
                        },
                      ),
                      _buildCategoryCard(
                        title: 'High-quality images',
                        imagePath: 'assets/hightquality.webp',
                        onTap: () {
                          Get.to(UserRatingsScreen());
                        },
                      ),
                      _buildCategoryCard(
                        title: 'Common diseases and pests',
                        imagePath: 'assets/common disease.webp',
                        onTap: () {
                          Get.to(CommonDiseasesScreen());
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Greeting Logic
  String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Morning';
    } else if (hour < 17) {
      return 'Afternoon';
    } else if (hour < 20) {
      return 'Evening';
    } else {
      return 'Night';
    }
  }

  IconData getGreetingIcon() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return Icons.wb_sunny;
    } else if (hour < 17) {
      return Icons.wb_cloudy;
    } else if (hour < 20) {
      return Icons.nights_stay;
    } else {
      return Icons.bedtime;
    }
  }

  // Action Card Widget
  Widget _buildActionCard({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Card(
          color: Colors.green,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    color: WColors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: WColors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Category Card Widget
  Widget _buildCategoryCard({
    required String title,
    required String imagePath,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 3,
        color: Colors.green,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(12),
              ),
              child: Image.asset(
                imagePath,
                fit: BoxFit.cover,
                height: 80,
                width: double.infinity,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: WColors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
