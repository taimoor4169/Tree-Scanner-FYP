
import 'package:flutter/material.dart';

class SimilarPlantsScreen extends StatelessWidget {
  static const routeName = '/similar_plants';

  const SimilarPlantsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Information on Similar Plants'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Similar Plants to Common Trees',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Here are some plants that share similarities with common tree species:',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            _buildSimilarPlantInfo(
              'Maple (Acer) and Boxelder (Acer negundo)',
              'Maple and Boxelder are both part of the Acer genus and share similar leaf shapes. However, Boxelder is more shrubby and often has a compound leaf structure unlike the typical simple leaves of most maples.',
            ),
            const SizedBox(height: 20),
            _buildSimilarPlantInfo(
              'Oak (Quercus) and Beech (Fagus)',
              'Oaks and Beeches can look quite similar due to their broad leaves and strong, sturdy trunks. However, Beech trees have smoother bark and simpler leaf shapes compared to the lobed leaves of Oaks.',
            ),
            const SizedBox(height: 20),
            _buildSimilarPlantInfo(
              'Pine (Pinus) and Spruce (Picea)',
              'Pines and Spruces are both conifers, but they can be distinguished by their needles. Pines have needles in clusters, whereas Spruces have single needles attached directly to the branches.',
            ),
            const SizedBox(height: 20),
            _buildSimilarPlantInfo(
              'Birch (Betula) and Aspen (Populus tremuloides)',
              'Birch and Aspen both have white bark and similar overall appearances. Birch bark peels off in thin layers, while Aspen bark tends to be smooth with black scars.',
            ),

          ],
        ),
      ),
    );
  }

  Widget _buildSimilarPlantInfo(String title, String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          description,
          style: const TextStyle(fontSize: 16, color: Colors.black54),
        ),
      ],
    );
  }
}
