import 'package:flutter/material.dart';
import 'add_review_screen.dart';

class UserRatingsScreen extends StatefulWidget {
  static const routeName = '/user_ratings';

  const UserRatingsScreen({Key? key}) : super(key: key);

  @override
  _UserRatingsScreenState createState() => _UserRatingsScreenState();
}

class _UserRatingsScreenState extends State<UserRatingsScreen> {
  final List<Map<String, dynamic>> userReviews = [
    {
      'name': 'Waleed Khan',
      'rating': 4,
      'comment': 'Great app for tree lovers! Helped me identify several trees in my garden.'
    },
    {
      'name': 'Awais Mushtaq',
      'rating': 5,
      'comment': 'Very useful app. Easy to use and provides accurate information about trees.'
    },
    {
      'name': 'Taimoor Ali',
      'rating': 3,
      'comment': 'Good app but could use more detailed information on tree diseases.'
    },
  ];

  void _addReview(String name, int rating, String comment) {
    setState(() {
      userReviews.add({
        'name': name,
        'rating': rating,
        'comment': comment,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Reviews and Ratings'),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
           // Navigator.pushReplacementNamed(context, DetailsScreen.routeName);
          },
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: userReviews.length,
        itemBuilder: (context, index) {
          final review = userReviews[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: ListTile(
              title: Text(
                review['name'] as String,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: List.generate(
                      5,
                          (starIndex) => Icon(
                        starIndex < (review['rating'] as int) ? Icons.star : Icons.star_border,
                        color: Colors.yellow,
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(review['comment'] as String),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddReviewScreen(onAddReview: _addReview)),
          );
        },
        backgroundColor: Colors.green,
        child: const Icon(Icons.add),
      ),
    );
  }
}
