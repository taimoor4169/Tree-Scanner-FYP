import 'package:flutter/material.dart';
import 'article_detail_screen.dart';

class ArticlesAndGuidesScreen extends StatelessWidget {
  const ArticlesAndGuidesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final articles = [
      {
        'title': 'How to Plant a Tree: A Step-by-Step Guide',
        'summary': 'Learn how to plant and care for a tree with this comprehensive guide.',
        'content': 'Choose the right tree for your location. Dig a hole twice the width and depth of the root ball. Place the tree in the hole and backfill with soil. Water thoroughly and add mulch around the base. Regularly water and maintain the tree to ensure healthy growth.'
      },
      {
        'title': 'The Benefits of Trees in Urban Areas',
        'summary': 'Discover the numerous benefits trees provide in cities and urban settings.',
        'content': 'Trees in urban areas provide shade, reduce heat, improve air quality, and enhance aesthetic value. They also offer habitat for wildlife, reduce stormwater runoff, and can increase property values. Planting trees in cities contributes to healthier and more sustainable environments.'
      },
      {
        'title': 'Common Tree Diseases and How to Treat Them',
        'summary': 'A guide to identifying and treating common diseases that affect trees.',
        'content': 'Common tree diseases include powdery mildew, canker, root rot, and leaf spots. Treatment involves pruning affected areas, improving drainage, applying fungicides, and ensuring proper tree nutrition. Regular monitoring and care can prevent the spread of diseases.'
      },
      {
        'title': 'Selecting the Right Tree for Your Yard',
        'summary': 'Tips for choosing the best tree species for your garden or backyard.',
        'content': 'Consider your climate, soil type, and space when selecting a tree. Choose species that thrive in your conditions and match your landscape goals. Think about the tree\'s mature size, growth rate, and maintenance needs. Native species are often the best choice for sustainability.'
      },
      {
        'title': 'Pruning Trees: Best Practices and Techniques',
        'summary': 'Learn the best practices and techniques for pruning your trees effectively.',
        'content': 'Prune trees during the dormant season to shape them, remove dead branches, and promote healthy growth. Use clean, sharp tools to make precise cuts. Avoid cutting too close to the trunk to prevent damage. Regular pruning helps maintain the tree\'s structure and health.'
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Articles & Guides'),
        backgroundColor: Colors.green,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: articles.length,
        itemBuilder: (context, index) {
          final article = articles[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: ListTile(
              title: Text(
                article['title']!,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(article['summary']!),
              trailing: const Icon(Icons.arrow_forward, color: Colors.green),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ArticleDetailScreen(
                      title: article['title']!,
                      content: article['content']!,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
