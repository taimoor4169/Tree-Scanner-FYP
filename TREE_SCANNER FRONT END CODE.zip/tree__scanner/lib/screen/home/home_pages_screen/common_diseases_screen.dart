import 'package:flutter/material.dart';

class CommonDiseasesScreen extends StatelessWidget {
  static const routeName = '/common_diseases';

  const CommonDiseasesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Common Diseases and Pests'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Common Diseases and Pests in Trees',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Here are some common diseases and pests that affect trees:',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            _buildDiseaseInfo(
              'Powdery Mildew',
              'Powdery mildew is a fungal disease that appears as white or gray powdery spots on leaves and stems. It thrives in warm, dry climates and can affect many types of trees. Treatment includes improving air circulation and applying fungicides.',
            ),
            const SizedBox(height: 20),
            _buildDiseaseInfo(
              'Canker Disease',
              'Canker diseases cause lesions or sunken areas on the bark and stems of trees. They are often caused by fungi or bacteria entering through wounds. Pruning affected areas and applying fungicides can help manage canker diseases.',
            ),
            const SizedBox(height: 20),
            _buildDiseaseInfo(
              'Root Rot',
              'Root rot is caused by fungi that thrive in overly wet soils, leading to the decay of roots. It results in wilting and yellowing of leaves. Prevention includes ensuring proper drainage and avoiding overwatering.',
            ),
            const SizedBox(height: 20),
            _buildDiseaseInfo(
              'Aphids',
              'Aphids are small insects that suck sap from leaves and stems, causing them to curl and yellow. They also produce a sticky substance called honeydew that attracts ants and can lead to sooty mold growth. Treatment includes spraying with insecticidal soap or neem oil.',
            ),
            const SizedBox(height: 20),
            _buildDiseaseInfo(
              'Leaf Spot',
              'Leaf spot diseases are caused by fungi or bacteria, leading to spots or blotches on leaves. They can weaken the tree if severe. Treatment includes removing affected leaves and applying fungicides.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDiseaseInfo(String title, String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          description,
          style: const TextStyle(fontSize: 16, color: Colors.black54),
        ),
      ],
    );
  }
}
