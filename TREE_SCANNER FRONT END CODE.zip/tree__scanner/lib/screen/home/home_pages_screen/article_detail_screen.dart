import 'package:flutter/material.dart';

class ArticleDetailScreen extends StatelessWidget {
  static const routeName = '/article_detail';

  final String title;
  final String content;

  const ArticleDetailScreen({
    Key? key,
    required this.title,
    required this.content,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(
            content,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}
