
import 'package:flutter/material.dart';

class FungalGrowthScreen extends StatelessWidget {
  static const routeName = '/fungal_growth';

  const FungalGrowthScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fungal Growth'),
        backgroundColor: Colors.green,
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Fungal Growth',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Fungal growth on or around trees can indicate several issues, including:',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              Text(
                '1. Root Rot',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Root rot is caused by soil-borne fungi that thrive in waterlogged soil. Ensure proper drainage and avoid overwatering to prevent root rot.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              Text(
                '2. Wood Decay',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Wood-decaying fungi cause the breakdown of tree tissues, often leading to structural weakness. Regularly inspect and remove decaying wood to manage this issue.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              Text(
                '3. Leaf Spots and Blights',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Fungal pathogens can cause leaf spots and blights, affecting leaf health. Pruning affected areas and applying fungicides can control the spread.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              Text(
                '4. Mold and Mildew',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Mold and mildew growth on leaves or branches can indicate high humidity or poor air circulation. Improve airflow and treat with appropriate fungicides.',
                style: TextStyle(fontSize: 16),
              ),
              // Add more detailed information as needed
            ],
          ),
        ),
      ),
    );
  }
}
