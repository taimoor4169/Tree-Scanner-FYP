class WImages{
   // -- App Logos
  static const String darkAppLogo = "assets/logo/logo.png";
  static const String lightAppLogo = "assets/logo/logo.png";
  static const String blacklogo = "assets/logos/splash_logo.png";

  // -- Social Logos
  static const String google = "assets/logos/google-icon.png";
  static const String facebook = "assets/logo/facebook-icon.png";

  //Profile
  static const String user = "assets/images/content/user.png";

  // -- OnBoarding Texts
  static const String onBoardingImage1 = "assets/images/on_boarding/on_boarding_1.png";
  static const String onBoardingImage2 = "assets/images/on_boarding/on_boarding_2.png";
  static const String onBoardingImage3 = "assets/images/on_boarding/on_boarding_3.png";

  // -- Animations
  static const String productsIllustration = "assets/animations/sammy-line-workout.gif";
  static const String productsSaleIllustration = "assets/animations/sammy-line-sale.png";
  static const String staticSuccessIllustration = "assets/animations/sammy-line-success.png";
  static const String deliveredInPlaneIllustration = "assets/animations/sammy-line-come-back-later.png";
  static const String deliveredEmailIllustration = "assets/animations/sammy-line-man-receives-a-mail.png";
  static const String verifyIllustration = "assets/animations/sammy-line-travel-backpack-with-passport-and-air-ticket.gif";

  // Lottie Animation
  static const String docerAnimation = "assets/animations/141594-animation-of-docer.json";
  static const String successfullyRegisterAnimation = "assets/animations/72462-check-register.json";
  static const String thankyouAnimation = "assets/animations/104368-thank-you.json";
  static const String emptyAnimation = "assets/animations/53207-empty-file";
  static const String loadingJunggleAnimation = "assets/animations/141397-loading-juggle.json";
  static const String orderCompletedAnimation = "assets/animations/order-complete-car-delivery-animation.json";
  static const String loaderAnimation = "assets/animations/loader-animation.json";
  static const String pencilAnimation = "assets/animations/140429-pencil-drawing.json";
}